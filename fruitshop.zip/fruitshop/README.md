# 🍊 FruitHaven — Fresh Fruit Ordering Website

A beautiful, fully functional fruit ordering website with cart functionality, product filtering, and order placement.

## ✨ Features

- 🛒 Add to cart with quantity control
- 🔍 Filter by category (Tropical, Berries, Citrus, Stone Fruits)
- 📱 Fully responsive (mobile, tablet, desktop)
- 🎨 Stunning animations and modern design
- 💬 Contact form
- ✅ Order confirmation flow

## 🚀 Deploy to Vercel (Recommended)

### Option 1: Vercel CLI
```bash
npm install -g vercel
cd fruitshop
vercel
```
Follow the prompts — your site will be live in ~30 seconds!

### Option 2: Vercel GitHub Integration
1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → New Project
3. Import your GitHub repo
4. Click **Deploy** — done! ✅

## 🐙 Deploy via GitHub Pages

1. Push to a GitHub repo
2. Go to **Settings → Pages**
3. Source: `Deploy from a branch` → `main` → `/ (root)`
4. Your site is live at `https://yourusername.github.io/fruitshop`

## 📁 Project Structure

```
fruitshop/
├── index.html        # Main HTML page
├── css/
│   └── style.css     # All styles
├── js/
│   └── app.js        # Cart, filtering, modals
├── vercel.json       # Vercel deployment config
└── README.md
```

## 🛠 Local Development

Just open `index.html` in your browser — no build tools needed!

```bash
# Or use a local server:
npx serve .
# or
python3 -m http.server 3000
```

## 📦 Customization

- **Add products**: Edit the `products` array in `js/app.js`
- **Change currency**: Replace `৳` with your currency symbol in `js/app.js`
- **Colors**: Edit CSS variables in `css/style.css` (`:root` section)
- **Delivery area / contact**: Update the contact section in `index.html`
